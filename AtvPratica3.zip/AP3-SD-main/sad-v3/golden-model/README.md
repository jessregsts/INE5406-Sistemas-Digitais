Dentro da pasta golden-model, você encontrará o arquivo golden-model.py e este README.md. 
Abrindo um terminal nessa pasta, execute 
> `python3 golden-model.py`

Ao final da execução a mensagem "Arquivo "estimulos.dat" exportado com sucesso!" deveria aparecer, assim como um novo arquivo estimulos.dat dentro da mesma pasta onde golden-model.py está.