# Grupo B

# Dados dos alunos
Nome: Jessica Regina dos Santos 
Matrícula: 22100626

Nome: Gustavo Hideki Guenka Vale
Matrícula: 21202112

# Descrição do Trabalho
Neste trabalho implementamos duas verões de testbenches para circuitos que calculam a SAD (Sum of Absolute Differences): sad-v1 e sad-v3, ambos circuitos retirados da AP2.

# Explicação geral
Neste trabalho utilizamos a IDE Quartus II. Implementamos cada testbench e executamos na plataforma para testar as entradas e saídas dos circuitos que calculam a sad-v1 e sad-v3.

---

- ## Testbench sad-v1
    Com os dados de estímulos dentro do arquivo do testbench, esse testbench automaticamente verifica o resultado dos testes ao ser executado usando o ModelSim.

    ---


- ## Testbench sad-v3
    Com os dados de estímulos gerados por um script em Python, esse testbench verifica automaticamente o resultado que está presente no arquivo de estímulos que foi gerado. Aqui usamos um conjunto de dados gerados aleatoriamente que consiste em 50 pares de blocos 8x8).

    ---